#!/usr/bin/env bash
# DualLens — repeatable local setup (no cloud notebook needed).
# Run from the folder containing this file + requirements.txt.
# Usage:  bash setup_local.sh
set -e

ENV_NAME="duallens"

echo ">>> Creating conda env '$ENV_NAME' (Python 3.11) if it doesn't exist..."
conda env list | grep -q "$ENV_NAME" || conda create -n "$ENV_NAME" python=3.11 -y

echo ">>> Installing packages from requirements.txt..."
conda run -n "$ENV_NAME" pip install -r requirements.txt

echo ">>> Registering '$ENV_NAME' as a Jupyter kernel..."
conda run -n "$ENV_NAME" python -m ipykernel install --user --name "$ENV_NAME" --display-name "Python (duallens)"

echo ">>> Done. Launch with:  conda activate $ENV_NAME && jupyter lab"
