# DualLens Analytics — Complete Build Playbook

A **click-by-click, copy-paste guide** to building DualLens 2.0: an evaluation-driven RAG
(Retrieval-Augmented Generation) system that ranks tech companies for investment, **and proves
its own answers are trustworthy**.

> Written so that *anyone* — even with no prior setup — can rebuild this from scratch on a Mac,
> fully **local** (no Google Colab / no cloud notebook), and understand *why* each step exists.

---

## 0. What you are building (read this first — 2 min)

A boutique research firm's first AI assistant *confidently made things up* (it invented a product
timeline that existed in no document). The lesson: **getting an AI to answer is easy; getting
answers you can trust, measure, and improve is the real problem.**

DualLens is the cure, built in 6 stages. Hold this mental model the whole way:

```
1. Financial Lens   → the NUMBERS  (stock trends, valuations)            ─┐
2. Narrative Lens   → the STORY    (each company's AI plans, from PDFs)   ├─ get both sides
3. Grounded RAG     → answer ONLY from real documents, else "I don't know"│  ← anti-hallucination
4. Evaluate         → 3 AI "judges" + a 20-question answer key            │  ← MEASURE it
5. Optimize         → DSPy+GEPA auto-rewrites the prompt from feedback    │  ← IMPROVE it
6. Decision Layer   → fuse both lenses → ranked rec + confidence + route ─┘  ← the deliverable
```

The three ideas, simplified: **(a) get both sides → (b) force it to be honest → (c) prove it's honest.**

### Plain-English glossary
| Term | What it means |
|---|---|
| **RAG** | Fetch the relevant documents *first*, then make the AI answer **using only those documents**. |
| **Embedding** | Turning a sentence into a list of numbers that captures its *meaning*, so a computer can find similar text. |
| **Vector database (ChromaDB)** | A store that, given a question, instantly returns the chunks closest in *meaning*. |
| **Chunking** | Splitting long PDFs into paragraph-sized pieces before storing them. |
| **Grounding / "I don't know" guardrail** | A prompt rule: answer only from retrieved text; if it's not there, say "I don't know." |
| **LLM-as-Judge** | Using a second AI to grade the first AI's answers 1–5. |
| **DSPy + GEPA** | A tool that **rewrites your prompt automatically** to score higher, proven on held-out questions. |

---

## 1. Files & accounts you need before starting

| Item | Where it comes from | Notes |
|---|---|---|
| `DualLens_..._Learners_Notebook.ipynb` | Course portal | The skeleton notebook with `📝 YOUR TASK` cells |
| `Companies-AI-Initiatives/` (5 PDFs: GOOGL/MSFT/IBM/NVDA/AMZN) | Course portal | The narrative-lens source documents |
| `golden_retrieval.csv` | Course portal | 20 questions + expected keyword, 4 per company |
| **API key + base URL** | Course portal (Great Learning) | Goes into `config.json`. **Keep secret — never commit it.** |

Put the data in one folder, e.g. `~/Downloads/Project_Datafiles/` containing
`Companies-AI-Initiatives/` and `golden_retrieval.csv`.

---

## 2. Environment setup — LOCAL (no cloud)

**Why local?** Many workplaces forbid running work on Google's servers (data governance). Everything
here runs on *your* machine. (The LLM calls still go to the course's API proxy — unavoidable for this
assignment, which mandates `gpt-4o-mini`. For a fully-offline version later, swap that proxy for a
local Ollama model.)

**Why a separate conda environment?** The notebook needs `dspy==3.2.1` and `langchain>=1.0`, which
require **Python 3.10+**. The Mac's system Python is often 3.9 and will fail. A dedicated env keeps
versions clean and reproducible, and never pollutes your other projects.

### 2a. Create the environment (one time)
Open **Terminal** and run:
```bash
conda create -n duallens python=3.11 -y
```
*Rationale: Python 3.11 is the safe sweet spot for dspy + langchain (3.13 can be too new for some deps).*

### 2b. Install the packages
Save `requirements.txt` (included in this repo) next to where you'll work, then:
```bash
/opt/anaconda3/envs/duallens/bin/pip install -r requirements.txt
```
*Rationale: installing with the env's **own** pip (full path) guarantees packages land in `duallens`,
not your base environment. This avoids the #1 Jupyter trap (see Troubleshooting).*

### 2c. Register the env as a Jupyter kernel
```bash
/opt/anaconda3/envs/duallens/bin/python -m ipykernel install --user --name duallens --display-name "Python (duallens)"
```
*Rationale: this makes "Python (duallens)" selectable as a kernel inside VS Code / Jupyter.*

> 💡 **Shortcut:** the included `setup_local.sh` does 2a–2c in one command: `bash setup_local.sh`

### 2d. Create `config.json` (holds your API credentials)
In your working folder (e.g. `~/Downloads`), create a file named **exactly** `config.json`:
```json
{
  "API_KEY": "gl-...your-course-key...",
  "OPENAI_API_BASE": "https://aibe.mygreatlearning.com/openai/v1"
}
```
*Rationale: the notebook's setup cell reads `config.json` and loads these into environment variables.
The filename must be `config.json` (not `configure.json`).* **Do NOT commit this file** — it contains a secret.

### 2e. Verify the connection (before any real work)
```bash
cd ~/Downloads
/opt/anaconda3/envs/duallens/bin/python -c "
import json, os
cfg=json.load(open('config.json'))
os.environ['OPENAI_API_KEY']=cfg['API_KEY']; os.environ['OPENAI_BASE_URL']=cfg['OPENAI_API_BASE']
from openai import OpenAI
print('Connectivity:', OpenAI().chat.completions.create(model='gpt-4o-mini',
      messages=[{'role':'user','content':'Reply with exactly: OK'}], max_tokens=5).choices[0].message.content)
"
```
Expected output: `Connectivity: OK`. If you see that, your environment is live.

---

## 3. Open the notebook & set the kernel

1. Open **VS Code** → **File → Open Folder** → choose `~/Downloads`.
2. Double-click the `...Learners_Notebook.ipynb` to open it in the notebook editor.
3. **Top-right of the notebook → click the kernel name → choose `Python (duallens)`.**
   - *Rationale: this is the #1 source of confusing errors. If the kernel is "base" or "Python 3",
     none of your installed packages are visible. Confirm with a cell:* `import sys; print(sys.executable)`
     *— it must contain `/envs/duallens/`.*
4. **Skip the `!pip install` cell** (the one starting `!pip install -q --upgrade ...`). You already
   installed everything locally. Running it can install into the wrong environment.

### THE GOLDEN RULE
**Run cells top-to-bottom, in order.** Each cell uses variables defined by the cells above it. If you
skip one, the next will throw `NameError`. To re-run cleanly: **Kernel → Restart**, then **Run All**
(or run from the config cell downward).

### Two Colab→local path fixes (required)
The notebook was written for Colab and hard-codes `/content/...` paths. Change these two cells:

- **The "Unzip the AI-initiative documents" cell** — replace its whole body with:
  ```python
  # 📂 Point at the local AI-initiative documents (already unzipped).
  import os
  PDF_DIR = "/Users/macbookpro/Downloads/Project_Datafiles/Companies-AI-Initiatives"
  pdf_files = sorted(f for f in os.listdir(PDF_DIR) if f.endswith(".pdf"))
  print("Documents found:", pdf_files)
  ```
- **The "Load the gold dataset" cell** — change the path to:
  ```python
  gold = pd.read_csv("/Users/macbookpro/Downloads/Project_Datafiles/golden_retrieval.csv")
  ```
*Rationale: these point the code at your local files instead of Colab's `/content/`. They change
**where files load from**, not what the pipeline does — outputs stay identical.*

---

## 4. Stage 1 — Financial Lens

**Goal:** pull 3 years of prices + 5 headline metrics for the 5 companies and chart them. No AI here —
pure data. This is the *quantitative* half that feeds the final ranking.

**Cell — 3-year price chart** (fill the two `...`):
```python
    data = ticker.history(period="3y")
    plt.plot(data.index, data["Close"], label=symbol)
```
**Cell — metrics DataFrame** (fill the four metric keys + two rescales):
```python
    "P/E Ratio":      info.get("trailingPE", 0),
    "Dividend Yield": info.get("dividendYield", 0),
    "Beta":           info.get("beta", 0),
    "Total Revenue":  info.get("totalRevenue", 0),
# ...bottom of the cell:
fin_df["Market Cap"]    = fin_df["Market Cap"] / 1e9
fin_df["Total Revenue"] = fin_df["Total Revenue"] / 1e9
```
**Cell — per-metric bar charts** (fill the one `...`):
```python
    plt.bar(fin_df.index, fin_df[metric])
```
Run each (**Shift+Enter**). **Rationale for `.get(key, 0)`:** some companies don't report every field
(Amazon pays no dividend). `.get` returns `0` instead of crashing the whole loop with a `KeyError`.

✅ Expect: a 5-line price chart, a `fin_df` table (NVDA/GOOGL market cap in the thousands-of-billions),
and 5 bar charts.

> **→ Mazoon parallel:** this is the step where you'd ingest a mining client's hard numbers (tonnage,
> grade, opex/tonne, price deck) into a clean DataFrame.

---

## 5. Stage 2 — Narrative Lens (ingestion & vectorization)

**Goal:** turn the 5 PDFs into a searchable, **company-tagged** knowledge base. The single most
important decision: tagging every chunk with its company, so retrieval can be filtered later.

**Cell — load PDFs & tag** (fill three `...`):
```python
    loader = PyPDFLoader(os.path.join(PDF_DIR, fname))
    pages  = loader.load()
    for page in pages:
        page.metadata["company"] = ticker
```
**Cell — token-based chunking** (fill three `...`):
```python
    chunk_size=CHUNK_SIZE,
    chunk_overlap=CHUNK_OVERLAP,
)
chunks = text_splitter.split_documents(documents)
```
**Cell — sanity check** (fill the `...`):
```python
chunk_counts = Counter(c.metadata["company"] for c in chunks)
print("Chunks per company:", dict(chunk_counts))
print()
print("--- Sample chunk (first 400 chars) ---")
print(chunks[0].page_content[:400])
print(chunks[0].metadata)
```
**Cell — embed & store in ChromaDB** (fill two `...`):
```python
embedding_model = OpenAIEmbeddings(model=EMBEDDING_MODEL)
vectorstore = Chroma.from_documents(
    chunks,
    embedding_model,
    collection_name="ai_initiatives",
)
```
**Rationale:** `split_documents` (not `split_text`) keeps the `company` tag on every chunk. The embed
step is the first bulk API call — if it errors with a `base_url`/`401` problem, langchain isn't reading
`OPENAI_BASE_URL`; otherwise it prints the chunk count.

✅ Expect: `Loaded ~44 pages`, `Total chunks: ~108`, balanced per-company counts, metadata showing
`'company': 'AMZN'`, and `Vector store ready with 108 embedded chunks.`

> **→ Mazoon parallel:** chunk your Mazoon model + methodology by **section** (revenue build, opex,
> DCF, royalty) and tag each — same machinery, `section` tag instead of `company`.

---

## 6. Stage 3 — Grounded RAG

**Goal:** answer questions using only company-filtered retrieved passages, with a hard "I don't know"
guardrail. This is the anti-hallucination engine.

**Cell — v1.0 grounding system prompt** (write inside the `"""`), keep it MINIMAL:
```python
qna_system_message = """Answer the question using ONLY the information in the provided context.
If the context does not contain the answer, respond with exactly: "I don't know."
Do not refer to the context in your answer."""
```
*Rationale: keep it bare on purpose — Stage 4 measures its weaknesses and Stage 5's GEPA improves it.
A bloated prompt now leaves GEPA no room (the "monolithic prompt" trap).*

**Cell — retrieval helper** (fill two `...`):
```python
    search_filter = {"company": company} if company else None
    return vectorstore.similarity_search(question, k=k, filter=search_filter)
```
**Cell — the RAG function** (fill four `...`):
```python
    relevant_chunks = retrieve(question, company=company)
    context = format_context(relevant_chunks)
    messages = qna_prompt.format_messages(context=context, question=question)
    response = llm.invoke(messages)
```
*Rationale: `format_messages` (not `format`) returns the proper system+user message list; `llm.invoke`
takes that list. The `{"company": company}` filter is where your Stage-2 tag pays off.*

Then **run the 5 typed test cases**. ✅ Examples 1–4 give real grounded answers; **Example 5
(out-of-scope) must return exactly `I don't know.`** — that's the guardrail proving itself.

**Retrieval diagnostic cell** (fill five `...`):
```python
    company = row["ticker_hint"] if use_filter else None
    docs    = retrieve(row["question"], company=company)
    text    = " ".join(d.page_content for d in docs).lower()
    return {
        "hit":    row["expected_substring"].lower() in text,
        "purity": sum(d.metadata["company"] == row["ticker_hint"] for d in docs) / len(docs),
    }
```
*Rationale: this is an **LLM-free** test of retrieval — did the expected keyword even reach the chunks?
It tells you whether a failure is the retriever's fault or the generator's fault.*

---

## 7. Stage 4 — Evaluation (judges + gold baseline)

**Goal:** measure quality two ways: 3 LLM judges (subjective) + a 20-question answer key (objective).

**The design that matters:** each judge sees *different* inputs on purpose:
- **Groundedness** sees question+context+answer → is the answer backed by the context?
- **Context Relevance** sees question+context (NO answer) → did *retrieval* fetch the right material?
- **Answer Relevance** sees question+answer (NO context) → does the answer address the question?

**Cell — Context Relevance judge** (fill metric + instructions):
```
Metric:
Context Relevance — the retrieved context should contain the information needed to answer the question. The score is lowered when the context is missing key facts, is off-topic, or only partially covers what the question asks.
...
Instructions:
1. Briefly explain, step by step, whether the context contains the information needed to answer the question.
2. Then assign a rating using the evaluation criteria.
3. End your response with a line in EXACTLY this format: Score: <N>
```
**Cell — Answer Relevance judge** (same shape):
```
Metric:
Answer Relevance — the answer should directly address the main aspects of the question. The score is lowered when the answer is off-topic, incomplete, or answers a different question than the one asked.
...
Instructions:
1. Briefly explain, step by step, whether the answer addresses the main aspects of the question.
2. Then assign a rating using the evaluation criteria.
3. End your response with a line in EXACTLY this format: Score: <N>
```
**Cell — score parser:**
```python
    m = re.findall(r'(?im)^Score:\s*([1-5])\b', judge_text)
    if m:
        return int(m[-1])
    nums = re.findall(r'\b([1-5])\b', judge_text)
    return int(nums[-1]) if nums else 0
```
**Cell — evaluation loop:**
```python
    docs    = retrieve(question, company=company)
    context = format_context(docs)
    answer  = rag_answer(question, company=company)
    g = judge_llm.invoke(groundedness_prompt.format_messages(question=question, context=context, answer=answer)).content
    c = judge_llm.invoke(context_relevance_prompt.format_messages(question=question, context=context)).content
    a = judge_llm.invoke(answer_relevance_prompt.format_messages(question=question, answer=answer)).content
    return {
        "question": question, "answer": answer,
        "groundedness": extract_score(g),
        "context_relevance": extract_score(c),
        "answer_relevance": extract_score(a),
    }
```
**Cell — pass/fail table:**
```python
judge_df["pass_all"] = (
    (judge_df["groundedness"]        >= PASS_THRESHOLD)
    & (judge_df["context_relevance"] >= PASS_THRESHOLD)
    & (judge_df["answer_relevance"]  >= PASS_THRESHOLD)
)
```
**Cell — objective gold-set baseline:**
```python
        ans = answer_fn(row["question"], row["ticker_hint"])
        ...
        "exact_hit": row["expected_substring"].lower() in ans.lower(),
    ...
baseline_gold_df = run_gold_set(lambda q, ticker: rag_answer(q, company=ticker))
```
✅ Expect: the out-of-scope **Q4 fails on purpose** (proves the rubric discriminates); baseline gold
accuracy around **45%**. *That 45% is the number Stage 5 must beat.*

---

## 8. Stage 5 — Optimization (DSPy + GEPA)

**Goal:** let GEPA auto-rewrite the prompt to score higher, then prove the gain on 8 held-out questions
it never trained on.

**Cell — train/test split** (must keep `test_size=0.4, random_state=42`):
```python
train_df, test_df = train_test_split(gold, test_size=0.4, random_state=42, stratify=gold["ticker_hint"])
```
**Cell — DSPy Examples:**
```python
    return dspy.Example(
        question=row["question"], ticker_hint=row["ticker_hint"],
        expected_substring=row["expected_substring"],
    ).with_inputs("question", "ticker_hint")
```
*Rationale: `.with_inputs(...)` marks only the fields the program sees; `expected_substring` stays
metric-only so the program can't cheat.*

**Cell — the RAG program (Signature + Module)** — the docstring **is** the prompt GEPA evolves:
```python
class GroundedQA(dspy.Signature):
    """Answer the question using ONLY the information in the provided context. If the context does not contain the answer, respond with exactly: "I don't know." Do not refer to the context in your answer."""
    context  : str = dspy.InputField(desc="Retrieved passages from the company's AI-initiative report")
    question : str = dspy.InputField(desc="The user's question")
    answer   : str = dspy.OutputField(desc="The answer, grounded strictly in the context")

class GroundedRAG(dspy.Module):
    def __init__(self, k: int = TOP_K):
        super().__init__()
        self.k = k
        self.generate = dspy.Predict(GroundedQA)
    def forward(self, question: str, ticker_hint: str):
        docs    = retrieve(question, company=ticker_hint, k=self.k)
        context = format_context(docs)
        return self.generate(context=context, question=question)
```
> ⚠️ **Common bug:** the skeleton hints at `metadata_filtered_retrieval(...)` — that function does NOT
> exist. Use your real `retrieve(question, company=ticker_hint, k=self.k)`.

**Cell — GEPA metric** (fill the 3 non-worked branches):
```python
    elif hit:
        score = 0.7
        feedback = (f"The answer correctly names '{expected}' but is too long ({n_words} words). "
                    f"Answer in 1-3 precise sentences leading with the specific name.")
    elif "i don't know" in answer.lower():
        score = 0.0
        feedback = (f"Wrongful refusal: the context DOES contain '{expected}'. "
                    f"Do not say 'I don't know' when the context supports an answer — state '{expected}'.")
    else:
        score = 0.0
        feedback = (f"Missed: the answer never contains '{expected}'. "
                    f"Name the exact product/initiative '{expected}', not a paraphrase.")
```
*Rationale: a number alone reduces GEPA to random search. The **feedback string** is what teaches the
optimizer what to fix — this is the most important idea in the stage.*

**Cell — run GEPA** (provided): just run it. Takes ~2–5 min, prints lots of progress — let it finish
until `GEPA compilation complete.`

**Cell — held-out proof** (fill four `...`):
```python
    pred      = optimised_program(question=row["question"], ticker_hint=row["ticker_hint"])
    v2_answer = pred.answer
    ...
        "v1_hit":  bool(v1_test.loc[row["question"], "exact_hit"]),
        "v2_answer": v2_answer,
        "v2_hit":  row["expected_substring"].lower() in v2_answer.lower(),
```
✅ Expect held-out **v1.0 ~25% → v2.0 ~62%**. The jump on *unseen* questions is the whole point:
improvement by evidence, not by memorizing. Residual misses are usually **retrieval**-limited (no
prompt can fix evidence that never reached the context).

---

## 9. Stage 6 — Decision Layer (fused ranking + confidence routing)

**Cell — evidence digests** (fill two `...`):
```python
    docs = retrieve(DIGEST_QUERY, company=ticker, k=3)
    company_digests[ticker] = "\n".join(f"- {doc.page_content}" for doc in docs)
```
**Cell — fused ranking prompt** (write the system message):
```python
ranking_system_message = """You are a senior investment analyst. Using ONLY the financial data and AI-initiative evidence supplied by the user, rank the five organizations from 1 (strongest) to 5 (weakest).
- Justify EVERY rank by citing at least one financial metric AND at least one NAMED initiative from the evidence.
- Use ONLY the supplied evidence (no outside knowledge).
- Output a numbered list (1-5) with 2-3 sentence justifications.
- End with a one-line caveat naming any company whose evidence felt thin."""
```
**Cell — ranking groundedness** (fill three `...`):
```python
        context=ranking_user_message,
        answer=recommendation.content,
    )
).content
ranking_groundedness = extract_score(ranking_groundedness_raw)
```
**Cell — confidence + routing** (fill the signals + routing):
```python
judge_mean_signal = in_scope[["groundedness","context_relevance","answer_relevance"]].values.mean() / 5
gold_signal       = v2_acc
ranking_signal    = ranking_groundedness / 5
confidence = round(100 * (0.40*gold_signal + 0.30*judge_mean_signal + 0.30*ranking_signal), 1)
if confidence >= CONF_CLIENT_READY:
    verdict, advice = "✅ CLIENT-READY", "Deliver to the client with the evaluation evidence attached."
elif confidence >= CONF_FLAGGED:
    verdict, advice = "⚠️ FLAGGED", "Share internally with a caveat; spot-check the weakest-evidence company before sending."
else:
    verdict, advice = "🛑 HELD FOR HUMAN REVIEW", "Do not send. An analyst must review before release."
```
✅ Expect a ranked 1–5 recommendation (each citing a metric + a named initiative) and a banner around
**72.5 / 100 → ⚠️ FLAGGED**. A "FLAGGED" verdict is a *correct* result — the system refuses to over-claim.

---

## 10. Stage 7 — Summary & Future Scope (writing only)

Fill the two markdown cells. Strong summaries **connect results across stages** (don't recap). Example
points: what the out-of-scope probe revealed about the metrics; how retrieval-vs-generation explained
both the baseline misses and GEPA's ceiling; what the evolved prompt taught about metric design.
Future scope: hybrid retrieval + reranking, stronger judge/reflection model, a dedicated GEPA valset,
live data, per-claim citations + production monitoring.

---

## 11. Export & submit

1. **VS Code:** open the Command Palette (**Cmd+Shift+P**) → "Jupyter: Export to HTML", **or** in Terminal:
   ```bash
   /opt/anaconda3/envs/duallens/bin/jupyter nbconvert --to html YOUR_NOTEBOOK.ipynb
   ```
2. Confirm every output is visible and prompts are inside `"""` triple quotes.
3. Upload the `.html` to the course portal.

> Tip: to run the whole thing unattended and produce a fully-populated HTML in one shot:
> ```bash
> cd ~/Downloads
> /opt/anaconda3/envs/duallens/bin/jupyter nbconvert --to notebook --execute --inplace \
>   --ExecutePreprocessor.timeout=1800 --ExecutePreprocessor.kernel_name=python3 YOUR_NOTEBOOK.ipynb
> ```

---

## 12. Troubleshooting (the exact issues we hit)

| Symptom | Cause | Fix |
|---|---|---|
| `ModuleNotFoundError` / packages missing | Wrong kernel (base, not duallens) | Kernel picker → **Python (duallens)**; verify `import sys; print(sys.executable)` shows `/envs/duallens/` |
| `!pip` warnings about `gtts`/`spyder` | `!pip` installed into base, not duallens | Ignore (harmless) and **skip the `!pip` cell** — install locally per §2 instead |
| `FileNotFoundError: /content/...` | Colab path on local machine | Apply the two path fixes in §3 |
| `NameError: name 'sample_pred' is not defined` (etc.) | Cells run out of order | Run **top-to-bottom**; or Kernel → Restart → Run All |
| `NameError: metadata_filtered_retrieval` | Skeleton hint names a non-existent function | Use `retrieve(question, company=ticker_hint, k=self.k)` |
| `'ChatOpenAI' object is not callable` | Called `judge_llm(...)` directly | Use `judge_llm.invoke(prompt.format_messages(...)).content` |
| `SyntaxError: unterminated triple-quoted string` / tangled cell | Pasted on top of old text | Click cell → **Cmd+A → Delete** → paste fresh |
| Edits keep "coming back" after close/reopen (VS Code) | VS Code **Hot Exit** restores unsaved buffers | Command Palette (**Cmd+Shift+P**) → **"Revert File"** to force-load the disk version |

---

## 13. What "good" looks like (reference results)

| Checkpoint | Expected |
|---|---|
| Pages loaded / chunks | ~44 pages → ~108 chunks, balanced across 5 companies |
| Out-of-scope test (Ex 5 / Q4) | returns `I don't know.` and scores low — *by design* |
| Gold baseline (v1.0) | ~45% |
| Held-out before/after | v1.0 ~25% → **v2.0 ~62%** |
| Final confidence | ~72.5 / 100 → ⚠️ FLAGGED |

*(Small run-to-run variance is normal — `gpt-4o-mini` isn't perfectly deterministic.)*

---

## 14. Appendix — why this matters beyond the course

This architecture is a template for any **grounded, self-verifying generator built on your own IP**.
Example: a **bankability-model generator** — retrieve proven model methodology, ground a new client
model on it, have judges score it, and confidence-route it before client delivery.

**Golden principle for that use case:** the LLM **retrieves the methodology and assembles the
structure**; a **deterministic engine (Excel/Python) computes the numbers**. Never let the LLM invent
figures — that's the one rule that separates a trustworthy tool from a liability.
